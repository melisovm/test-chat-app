# test-chat-app
### This is a test-app for  ***d.tkachenko@platformalp.ru***
To start this project firstly install dependencies
```
npm install
```
Run project 
```
npm run serve
```

Compiles and minifies for production
```
npm run build
```
